#include <iostream>
#include <ur_rtde/rtde_control_interface.h>
#include <ur_rtde/rtde_receive_interface.h>
#include <vector>
#include <thread>
#include <chrono>

using namespace ur_rtde;
using namespace std::chrono;

class URMover
{
public:
    //constructor

    ~URMover(){
        delete rtde_control;
    }

    explicit URMover(std::string _UR_IP):UR_IP(_UR_IP)
    {
        this->rtde_control = new RTDEControlInterface(UR_IP);
    }


    void SpeedJ(std::vector<double> joint_pose
                                    ,double acceleration=0.5
                                    ,double time = 0.0)
    {
        for (unsigned int i=0; i<10; i++)
        {
            rtde_control->speedJ(joint_pose, acceleration, time);
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        rtde_control->speedStop();
        
    }

    void SpeedL(std::vector<double> tool_speed
                                    ,double acceleration=0.25
                                    ,double time = 0.0)
    {
        for (unsigned int i=0; i<10; i++)
        {
            rtde_control->speedL(tool_speed, acceleration, time);
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        rtde_control->speedStop();
    }

    void MoveJ(std::vector<double> position
                                    ,double speed = 1.05
                                    ,double acceleration=1.4)
    {
        rtde_control->moveJ(position, speed, acceleration);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        rtde_control->stopJ(0.5);
    }

    void MoveJ_Blend(std::vector<double> position
                                            ,double speed = 1.05
                                            ,double acceleration = 1.4
                                            ,double blend = 0)
    {
        position.push_back(speed);
        position.push_back(acceleration);
        position.push_back(blend);
        std::vector<std::vector<double>> path;
        path.push_back(position);
        rtde_control->moveJ(path);
        rtde_control->stopScript();
    }                                        

    void MoveL(std::vector<double> pose
                                    ,double speed=0.25
                                    ,double acceleration=1.2)
    {
        rtde_control->moveL(pose,speed,acceleration);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        rtde_control->stopL(0.5);
    }


    void ForceMode(std::vector<double> task_frame = {0, 0, 0, 0, 0, 0}
                ,std::vector<int> selection_vector = {0, 0, 1, 0, 0, 0}
                ,std::vector<double> wrench_down = {0, 0, -20, 0, 0, 0}
                ,std::vector<double> wrench_up = {0, 0, 20, 0, 0, 0}
                ,int force_type = 2
                ,std::vector<double> limits = {2, 2, 1.5, 1, 1, 1})
    {
        rtde_control->forceModeStart(task_frame, selection_vector, wrench_down, force_type, limits);
        //std::cout << std::endl << "Going Down!" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(1));
        //std::cout << std::endl << "Going Up!" << std::endl << std::endl;
        rtde_control->forceModeUpdate(wrench_up);
        std::this_thread::sleep_for(std::chrono::seconds(1));
        rtde_control->forceModeStop();
    }

private:
    std::string UR_IP = "192.168.1.11";
    RTDEControlInterface* rtde_control;
};

int main(int, char**) {
    
    URMover *UR = new URMover("192.168.1.11");

    UR->ForceMode({},{},{},{});
    return 0;
    
    

    
/*
    RTDEControlInterface rtde_control("")
    //ServoJ Example
    std::vector<double> joint_q1 = {-0.25, -1.55, -2.05, -1.13, 1.59, -0.0255};
    double time = 0.5;
    double lookahead_time = 0.1;
    double gain = 300;
    double velocity = 0.1;
    double acceleration = 0.2;
    std::vector<double> init_q = rtde_receive.getActualQ();
    // rtde_control.servoJ(joint_q1,velocity,acceleration,time,lookahead_time,gain);
    // std::this_thread::sleep_for(std::chrono::milliseconds(2));
    // rtde_control.moveJ(init_q);
    
    for(unsigned int i=0; i<1000; i++)
    {
        joint_q1[0] += 0.001;
        joint_q1[1] += 0.001;
        rtde_control.servoJ(joint_q1, velocity, acceleration, time, lookahead_time, gain);
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    rtde_control.servoStop();


    //MoveJ Path with Blending Example
    // double acceleration = 1.2;
    // double velocity = 0.8;
    // double blend1 = 0;
    // double blend2 = 0.3;
    // double blend3 = 0;
    // std::vector<double> init_q = rr.getActualQ();
    // std::vector<std::vector<double>> path;
    // std::vector<double> pose1 = {-0.25, -1.55, -2.05, -1.13, 1.59, -0.0255, velocity, acceleration, blend1};
    // std::vector<double> pose2 = {0.27, -1.61, -1.83, -1.15, 1.60, 0.827, velocity, acceleration, blend2};
    // std::vector<double> pose3 = {-0.25, -1.75, -1.07, -2.03, 1.59, -0.0202, velocity, acceleration, blend3};
    // path.push_back(pose1);
    // path.push_back(pose2);
    // path.push_back(pose3);
    // rc.moveJ(path);
    // rc.moveJ(init_q);


    //MoveP / MoveC Circle Example
    // double velocity = 0.25;
    // double acceleration = 1.2;
    // double blend = 0.1;
    // std::vector<double> waypoint_1 = {0.600, -0.250, 0.500, 2.632, -1.712, -0.036};
    // std::vector<double> waypoint_2 = {0.699, -0.149 ,0.499, 2.631, -1.712, -0.037};
    // std::vector<double> waypoint_3 = {0.800, -0.249, 0.499, 2.632, -1.712, -0.038};
    // std::vector<double> waypoint_4 = {0.699, -0.350, 0.500, 2.632, -1.712, -0.038};
    // std::vector<double> waypoint_5 = {0.600, -0.250, 0.500, 2.633, -1.712, -0.036};
    
    // rc.moveL({0.600, -0.250, 0.500, 2.632, -1.712, -0.036});
    // for (unsigned int i=0; i<2; i++)
    //   {
    //     rc.moveP(waypoint_1, velocity, acceleration, blend);
    //     rc.moveC(waypoint_2, waypoint_3, velocity, acceleration, blend);
    //     rc.moveC(waypoint_4, waypoint_5, velocity, acceleration, blend);
    //   }
*/    
}
